<?php
/**
 * Created by PhpStorm.
 * User: HP
 * Date: 10-11-2018
 * Time: 13:33
 */

namespace Drupal\omdb_integration\Form;



use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\node\Entity\Node;
use Drupal\Core\Database\Database;

class AddNewMovie extends FormBase{

    public function getFormId()
    {
        // TODO: Implement getFormId() method.
        return 'get_movie_details';
    }

    public function buildForm(array $form, FormStateInterface $form_state)
    {
        // TODO: Implement buildForm() method.
        $form['title'] = array(
            '#type' => 'textfield',
            '#title' => 'Title',

        );
        $form['actions'] = array(
            '#type' => 'button',
            '#value' => t('Get Movie Details'),
            '#ajax' => [
              'callback' => 'Drupal\omdb_integration\Form\AddNewMovie::getMovieDetails',
            ],

        );

        $form['submit'] = array(
            '#type' => 'submit',
            '#value' => t('Save'),
        );
            return $form;
    }

    public function getMovieDetails(array &$form, array &$form_state){
        drupal_set_message("Test");
    }

    public function submitForm(array &$form, FormStateInterface $form_state)
    {
        $movie_title = $form_state->getValue('title');
        $uri = "http://www.omdbapi.com/?apikey=d969ddb7&t=.$movie_title.&r=json";
        try {
            $response = \Drupal::httpClient()->get($uri);
            $data = (string)$response->getBody();
            if (empty($data)) {
                return FALSE;
            }
        } catch (RequestException $e) {
            return FALSE;
        }

        $decoded_data = json_decode($data, true);
        if($decoded_data["Response"] === "False"){
            drupal_set_message("Please enter valid movie name.");
        }
        else {
            $movie_title_decoded = $decoded_data["Title"];

            $data_file = file_get_contents($decoded_data["Poster"]);

            //$data_file = system_retrieve_file($decoded_data["Poster"],'public://', TRUE);
          //  $t = \Drupal::service('file_system')->realpath($decoded_data["Poster"]);

            $file = file_save_data($data_file, 'public://', FILE_EXISTS_REPLACE);

            $connection = Database::getConnection();
            $query = $connection->select('node_field_data', 'node_data');
            $query->fields('node_data', array('title'));
            $query->condition('node_data.type', 'movie', '=');
            $query->condition('node_data.title', "%$movie_title_decoded%", 'LIKE');
            $data1 = $query->execute();
            $result = $data1->fetchAll(\PDO::FETCH_ASSOC);
            $result_title = $result[0]["title"];
            if (!$result_title) {
                $node = Node::create([
                    'type' => 'movie',
                    'title' => $decoded_data["Title"],
                    'field_actors' => $decoded_data["Actors"],
                    'field_country' => $decoded_data["Country"],
                    'field_genre' => $decoded_data["Genre"],
                    'field_language' => $decoded_data["Language"],
                    'field_poster' => [
                        'target_id' => $file->id(),
                        'alt' => 'Sample',
                        'title' => 'Sample File'
                    ],
                    'field_production' => $decoded_data["Production"],
                    'field_rating' => round($decoded_data["Ratings"][0]["Value"]),
                    'field_released' => $decoded_data["Released"],
                ]);
                $node->save();
                drupal_set_message("The Movie " . $decoded_data["Title"] . " saved Successfully");
            } else {
                drupal_set_message("The movie name " . $decoded_data["Title"] . " already exist. Please enter another.");
            }
        }
    }

}